
function addTask() {
    const newTaskInput = document.getElementById('new-task');
    const taskList = document.getElementById('task-list');

    if (newTaskInput.value.trim() === '') {
        alert('Por favor, ingrese una tarea válida.');
        return;
    }

    const taskText = document.createTextNode(newTaskInput.value);

    const taskItem = document.createElement('li');
    taskItem.classList.add('task');
    taskItem.appendChild(taskText);

    const doneButton = document.createElement('button');
    doneButton.innerText = 'Realizada';
    doneButton.onclick = function () {
        taskItem.style.textDecoration = 'line-through';
    };

    const deleteButton = document.createElement('button');
    deleteButton.innerText = 'Eliminar';
    deleteButton.onclick = function () {
        taskList.removeChild(taskItem);
    };

    taskItem.appendChild(doneButton);
    taskItem.appendChild(deleteButton);

    taskList.appendChild(taskItem);
    
    newTaskInput.value = '';
}
